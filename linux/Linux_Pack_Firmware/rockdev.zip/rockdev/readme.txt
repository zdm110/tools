**************Generate update.img******************
1.copy image and parameter to "rockdev/Image"
2.copy loader to "rockdev/Image/MiniLoaderAll.bin"
3.copy rootfs to "rockdev/Image/rootfs.img"
4.modify parameter and package-file
5.run mkupdate.sh to make update.img in "rockdev"
***************************************************

**************Unpack update.img********************
run unpack.sh
unpacking file in the "output"

***************************************************
